<?php 
$DB = '//10.1.1.1:1521/xe';
$DB_USER = 'hrmis';
$DB_PASS = 'hrmis';
$DB_CHAR = 'AL32UTF8';
$conn = oci_connect($DB_USER, $DB_PASS, $DB, $DB_CHAR);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>NHA - Notification</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- Datatable--->
  <link rel="stylesheet" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
  
  <!---- Custom CSS -->
  <style>
	table.dataTable thead th {border-bottom:none;}
	.table-bordered>tbody>tr>td,.table-bordered>thead>tr>th{border:none;}
	#header{padding-top:20px;height:80px;}
	#sub-header{padding:10px;}
  </style>
</head>
<body>

<div class="container">
	<!--<div id="header" class="row">
		<div class="col-md-4 col-sm-12">
			<img src="http://nha.gov.pk/wp-content/themes/nha/images/logo-en.png" />
		</div>
		<div class="col-md-8 col-sm-12">
			<h2>National Highway Authority</h2>
			<b>HRMIS</b>
		</div>
	</div>
	-->
	<div id="sub-header">
		<h2>Notifications</h2>
	</div>
            
  <table id="myTable" class="table table-bordered table-striped dtable dataTables">
    <thead>
      <tr>
        <th class="text-center">Sr. #</th>
        <th class="text-center">Notification #</th>
        <th class="text-center">Notification Date</th>
        <th class="text-center">Notification Type</th>
        <th class="text-center">Subject</th>
        <th class="text-center">Section</th>
        <th class="text-center">Approved Authority</th>
        <th class="text-center">Document</th>
        
      </tr>
    </thead>
    <tbody>
      


<?php



ini_set('max_execution_time', 5000);
$qry = oci_parse($conn, "SELECT * FROM V_ORDER WHERE ROWNUM <= 20");   //WHERE ROWNUM <= 20"

$data = oci_execute($qry);
//print_r($data);die;
$i=1;

while($row=oci_fetch_array($qry))

{
	if($row['ORDER_TYPE'] == 1)
                  $order = 'Order';
              elseif($row['ORDER_TYPE'] == 2)
                  $order = 'Circular';
              elseif($row['ORDER_TYPE'] == 3)
                  $order = 'Letter';
              else if($row['ORDER_TYPE'] == 4)
                  $order = 'Noting'; 
	echo '<tr>';
//var_dump($row);
$doc = '';
echo '<td class="text-center">'.$i.'</td>';
echo '<td class="text-center">'.$row['ORDER_NO'].'</td>';
echo '<td class="text-center">'.date('d-M-Y', strtotime($row['ORDER_DATE'])).'</td>';
echo '<td class="text-center">'.$order.'</td>';
echo '<td class="text-center">'.$row['ORDER_SUBJECT'].'</td>';
echo '<td class="text-center">'.$row['SECTION_NAME'].'</td>';
echo '<td class="text-center">'.$row['AA_NAME'].'</td>';
$doc = '<td class="text-center">';
//125.209.65.69:81/hrmis
if($row['E_DOC'])
	$doc.= '<a href="'.url().'download.php?file='.$row['E_DOC'].'" target="_blank"><i class="fa fa-file"></i></a>';
	//$doc.= '<a href="http://localhost/nha/'.$row['E_DOC'].'" target="_blank"><i class="fa fa-file"></i></a>';
$doc.='</td>';
echo $doc;

echo '</tr>';

$i++;

}
function url(){
  return sprintf(
    "%s://%s%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
    $_SERVER['SERVER_NAME'],
    $_SERVER['REQUEST_URI']
  );
}



//$statement = oci_parse($conn, 'select 1 from dual');
//oci_execute($statement);
//$row = oci_fetch_array($statement, OCI_ASSOC+OCI_RETURN_NULLS);
?>
	</tr>
	<tbody>
	<table>
</body>
<script>
$(document).ready(function(){
    $('#myTable').DataTable();
});
</script>
</html>