<?php 
require_once 'dompdf/autoload.inc.php';

// reference the Dompdf namespace
use Dompdf\Dompdf;
use Dompdf\Options;

$isRemoteEnabled = true;
$my_file = $_GET['file'];

// instantiate and use the dompdf class

$options = new Options();
$options->setIsRemoteEnabled(true);


$dompdf = new Dompdf($options);
$dompdf->loadHtml('<img src="http://125.209.65.69:81/hrmis/'.$my_file.'" alt="notification"/>');

// (Optional) Setup the paper size and orientation
//$dompdf->setPaper('A4', 'landscape');

// Render the HTML as PDF
$dompdf->render();
// Output the generated PDF to Browser
//$dompdf->stream();
$dompdf->stream('download.pdf',array('Attachment'=>false));

?>